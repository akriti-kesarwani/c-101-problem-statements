#include <iostream>
using namespace std;

int main() {
    int N;

    
    cout << "Enter the value of N: ";
    cin >> N;

    int i = 1;

    while (i <= N) {
        cout << i << " ";
        i++;
    }
cout<<"the value is:"<<i;
    return 0;
}